package com.example.ekraproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
/*
public class BtAdapter extends ArrayAdapter<ListItem> {
    public static final String DEF_ITEM_TYPE = "normal";
    public static final String TITLE_ITEM_TYPE = "tytle";
    public static final String DISCOVERY_ITEM_TYPE  = "discovery";
    private List<ListItem> mainList;
    private List<ViewHolder> viewHolderList;
    private SharedPreferences preferences;

    public BtAdapter(@NonNull Context context, int resource, List<ListItem> btList) {
        super(context, resource,btList);
        mainList = btList;
        viewHolderList = new ArrayList<>();
    preferences = context.getSharedPreferences(BtCONST.MY_PREF, context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        switch (mainList.get(position).getItemType()){
            case TITLE_ITEM_TYPE:
                convertView = titleItem(convertView,    parent);
                break ;
            default: DEF_ITEM_TYPE: convertView = defaultItem(convertView, position, parent);
            break;
        }
        return convertView;
    }

    private  void savePref(int pos){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(BtCONST.MAC_KEY, mainList.get(pos).getBtMac());
        editor.apply();
    }
    class ViewHolder{
        TextView tvBtName;
        CheckBox checkBox;
    }
    private View defaultItem(View convertView, int position, ViewGroup parent){
        ViewHolder viewHolder ;

        if (convertView == null){

            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(parent.      getContext()).inflate(R.layout.bt_list_item,null,false);
            viewHolder.tvBtName=convertView.findViewById(R.id.tvBtName);
            viewHolder.checkBox= convertView.findViewById(R.id.checkBox);
            convertView.setTag(viewHolder);
            viewHolderList.add(viewHolder);

        }else {
            viewHolder=(ViewHolder) convertView.getTag();
        }
        viewHolder.tvBtName.setText(mainList.get(position).getBtName());
        viewHolder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (ViewHolder viewHolder1 : viewHolderList) {
                    viewHolder1.checkBox.setChecked(false);
                }
                viewHolder.checkBox.setChecked(true);
                savePref(position);
            }
        });

        if(preferences.getString(BtCONST.MAC_KEY, "No bt selected").equals(mainList.get(position).getBtMac())){
            viewHolder.checkBox.setChecked(true);
        }
        return convertView;
    }



    private View titleItem(View convertView, ViewGroup parent){
        if (convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate
                    (R.layout.bt_list_tite_item,null,false);
        }
        return convertView;
    }


}

 */
